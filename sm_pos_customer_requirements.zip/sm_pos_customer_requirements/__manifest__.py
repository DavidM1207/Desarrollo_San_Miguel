# -*- coding: utf-8 -*-
{
    "name": "POS: Cliente con NIT, Teléfono y Móvil obligatorios (Sólo POS, Servidor)",
    
    "version": "17.0.2.0.0",
    "author": "San Miguel",
    
    "depends": ["point_of_sale"],
    "data": [
        "security/ir.model.access.csv",
        "security/security.xml"
    ],
    "application": False,
    "installable": True
}
